/**
 * 
 */
/**
 * @author WJL
 *
 */
module MyServer {
	requires java.sql;
	requires java.datatransfer;
	requires java.desktop;
}