package myserver;

import mydatabase.MyDB;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.BindException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.sql.SQLException;

import javax.swing.*;

public class MyServer {

	public ServerSocket server;
	private int serverPort = 8888;
	private InputStream in = null;
	private PrintWriter out;
	private MyDB mydb;

	public MyServer() {

		/*
		 * this.setTitle("Server"); this.setSize(250, 200); this.setVisible(true);
		 * this.setLayout(null); this.setLocationRelativeTo(null);
		 * this.setResizable(false);
		 * 
		 * JButton btn = new JButton("Close"); btn.setBounds(70, 75, 100, 30); //
		 * this.add(btn);
		 */

		try {
			server = new ServerSocket(serverPort);

			System.out.println("ServerSocket: " + server);

			mydb = new MyDB();

			// System.out.println("Server Reading:");
			// System.out.print(mydb.allevents);

		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	// �˰��������޷�����ʹ��
	/*
	 * btn.addActionListener(new ActionListener() {
	 * 
	 * @Override public void actionPerformed(ActionEvent e) { // TODO Auto-generated
	 * method stub try { dispose(); server.close();
	 * 
	 * } catch (IOException e1) { // TODO Auto-generated catch block
	 * e1.printStackTrace(); } } }); }
	 */

	// Start listening.
	private void listen() {
		boolean send = false;
		while (true) { // run until you terminate the program
			try {
				// Wait for connection. Block until a connection is made.
				Socket socket = server.accept();
				System.out.println("Socket: " + socket);
				in = socket.getInputStream();

				out = new PrintWriter(socket.getOutputStream());

				if (!send) {
					String temp = mydb.allevents;
					System.out.print(temp);
					out.println(temp);
					out.flush();
					send = true;
				}

				BufferedReader clientReader = new BufferedReader(new InputStreamReader(in));// ������
				String s;

				try {
					this.mydb.statement.execute("drop table if exists events");
					this.mydb.statement.execute("create table events (time string, event string)");
				} catch (SQLException e) {
					// if the error message is "out of memory",
					// it probably means no database file is found
					System.err.println(e.getMessage());
				} catch (Exception e) {
					e.printStackTrace();
				}
				while ((s = clientReader.readLine()) != null) {
					System.out.print(s);
					String[] temp = timeandevent(s);
					mydb.addEvent(temp[0], temp[1]);
				}

			} catch (BindException e) {
				e.printStackTrace();
				break; // Port already in use
			} catch (SocketException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					if (in != null)
						in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}

	public String[] timeandevent(String event) {
		String tes[] = event.split("Event: ");

		for (String t : tes) {
			System.out.print(t);
		}
		return tes;
	}

	public static void main(String[] args) {
		new MyServer().listen(); // Start the server and listening
	}
}
