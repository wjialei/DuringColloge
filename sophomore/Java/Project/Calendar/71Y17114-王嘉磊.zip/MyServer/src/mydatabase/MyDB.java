package mydatabase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MyDB {

	private Connection connection;
	private ResultSet rs;
	public Statement statement;
	public String allevents = new String();

	public static int cnt = 0;

	public MyDB() throws ClassNotFoundException {

		// load the sqlite-JDBC driver using the current class loader
		Class.forName("org.sqlite.JDBC");

		try {
			// create a database connection
			// note: select a propriate path of the SQlite database
			connection = DriverManager.getConnection("jdbc:sqlite:eventsDB.db");
			statement = connection.createStatement();
			statement.setQueryTimeout(30); // set timeout to 30 sec.
			// statement.executeUpdate("drop table if exists events");
			// statement.executeUpdate("create table events (time string, event string)");

			System.out.println("Data Reading:");
			read();

		} catch (SQLException e) {
			// if the error message is "out of memory",
			// it probably means no database file is found
			System.err.println(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void addEvent(String time, String event) {

		try {

			String t = "insert into events (time, event) values(" + "'" + time + "'" + "," + "'" + event + "'" + ")";
			System.out.println(t);

			statement.executeUpdate(t);

		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}

	// ɾ�����ݿ��е�ĳһ�¼���δ��ɣ���ʱ�޷�ʹ�ã�
	public void delEvent(String event) {
		try {
			String str = new String(event);
			statement.executeUpdate("delete from events where event = 'str'");

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void read() throws SQLException {
		rs = statement.executeQuery("select * from events");
		while (rs.next()) {
			// read the result set
			String time = new String(rs.getString("time"));
			String event = new String(rs.getString("event"));
			allevents += time + " Event: " + event + "\n";
		}
		System.out.print(allevents);
	}

	public static void main(String[] args) {

		try {
			MyDB m = new MyDB();
			// m.addEvent("2019-01-01", "Hello Java!");
			// m.addEvent("2019-01-01", "Hello World!");
		} catch (ClassNotFoundException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}

}
