package myclient;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class MyClient {

	public Socket client = null;
	private String serverAddr = "localhost";
	private int serverPort = 8888;
	// ��ȡһ��������,���շ���˵���Ϣ
	private InputStream in;
	private PrintWriter out;
	// ������
	private BufferedReader bufferedReader;

	public MyClient() {
		try {
			client = new Socket(serverAddr, serverPort);
			System.out.println("Client: " + client);

			out = new PrintWriter(client.getOutputStream());

			in = client.getInputStream();

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void sendMessage(String s) {
		out.print(s);
		out.flush();
	}

	public String receiveMessage() {

		String str = new String();
		bufferedReader = new BufferedReader(new InputStreamReader(in));
		String s;

		File f = new File("dbevents.txt");
		try {
			while ((s = bufferedReader.readLine()) != null) {
				System.out.println(s);
				str += s + "\n";
				if (s.isEmpty())
					break;
			}
		} catch (IOException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}

		return str;
	}
}
