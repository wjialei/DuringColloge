/**
 * 
 */
/**
 * @author WJL
 *
 */
module MyClient {
	requires java.desktop;
}