package window;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import myclient.MyClient;

public class CalendarWnd extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 544155737997484933L;

	// ��������
	private Font f = new Font("΢���ź�", Font.PLAIN, 15);
	private ImageIcon background;
	// Panel
	private JPanel datepanel, switchpanel, weekpanel, daypanel;

	// Month
	private String[] month = { "Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sep", "Oct", "Nov", "Dec" };
	private JLabel yearInputLabel, monthListLabel;
	private JTextField yearInput;
	private JComboBox<String> monthList = new JComboBox<String>();

	// Week0
	private JLabel[] weeks = new JLabel[7];
	private String[] weekName = { "     Sun", "     Mon", "     Tue", "     Wed", "     Thu", "     Fri", "     Sat" };
	// Day
	private JLabel[] days = new JLabel[42];
	// Current date
	Date currentDate = new Date();
	private JLabel currentYear;
	private JLabel currentMonth;

	// ���
	private JButton eventBtn;

	// �¼�
	private static ArrayList<String> mecontent = new ArrayList<String>();
	private static ArrayList<String> metime = new ArrayList<String>();

	// �ͻ���
	private MyClient mc;

	// constructor
	@SuppressWarnings("deprecation")
	public CalendarWnd() {

		this.setTitle("Calendar");
		this.setSize(600, 450);
		this.setVisible(true);
		this.setLayout(null);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		Container cp = this.getContentPane();
		datepanel = new JPanel();

		// ���ӱ���ͼƬ
		background = new ImageIcon("background1.jpg");
		JLabel backGroundLabel = new JLabel(background);
		backGroundLabel.setBounds(0, 0, 600, 450);
		JPanel imagePanel = (JPanel) this.getContentPane();
		imagePanel.setOpaque(false);
		this.getLayeredPane().add(backGroundLabel, new Integer(Integer.MIN_VALUE));

		// ���ö�����ݺ��·ݱ�ǩ
		cp.add(datepanel);
		datepanel.setBounds(0, 0, 600, 80);
		datepanel.setOpaque(false);
		datepanel.setLayout(null);
		Integer theYear = currentDate.getYear() + 1900;
		currentYear = new JLabel(theYear.toString());
		currentYear.setFont(new Font("΢���ź�", Font.ITALIC, 40));
		currentYear.setForeground(Color.RED);
		currentYear.setBounds(100, 5, 150, 45);
		Integer theMonth = currentDate.getMonth() + 1;
		switch (theMonth) {
		case 1:
			currentMonth = new JLabel("January");
			break;
		case 2:
			currentMonth = new JLabel("February");
			break;
		case 3:
			currentMonth = new JLabel("March");
			break;
		case 4:
			currentMonth = new JLabel("April");
			break;
		case 5:
			currentMonth = new JLabel("May");
			break;
		case 6:
			currentMonth = new JLabel("June");
			break;
		case 7:
			currentMonth = new JLabel("July");
			break;
		case 8:
			currentMonth = new JLabel("August");
			break;
		case 9:
			currentMonth = new JLabel("September");
			break;
		case 10:
			currentMonth = new JLabel("October");
			break;
		case 11:
			currentMonth = new JLabel("November");
			break;
		case 12:
			currentMonth = new JLabel("December");
			break;
		}
		currentMonth.setFont(new Font("΢���ź�", Font.ITALIC, 30));
		currentMonth.setForeground(Color.RED);
		currentMonth.setBounds(300, 5, 250, 45);
		datepanel.add(currentMonth);
		datepanel.add(currentYear);

		// ���������л�����
		switchpanel = new JPanel();
		cp.add(switchpanel);
		switchpanel.setBounds(0, 80, 600, 40);
		switchpanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		switchpanel.setOpaque(false);
		yearInputLabel = new JLabel("Year   ");
		switchpanel.add(yearInputLabel);
		yearInput = new JTextField(4);
		switchpanel.add(yearInput);
		monthListLabel = new JLabel("Month   ");
		monthListLabel.setForeground(Color.BLACK);
		;
		monthListLabel.setBounds(10, 100, 100, 20);
		switchpanel.add(monthListLabel);
		for (int i = 0; i < 12; i++) {
			monthList.addItem(month[i]);
		}
		monthList.setBounds(10, 100, 100, 20);
		switchpanel.add(monthList);

		eventBtn = new JButton("Event");
		switchpanel.add(eventBtn);

		// �����ܱ���
		weekpanel = new JPanel();
		weekpanel.setOpaque(false);
		cp.add(weekpanel);
		weekpanel.setBounds(20, 120, 560, 20);
		weekpanel.setLayout(new GridLayout(1, 7, 2, 2));
		for (int i = 0; i < 7; i++) {
			weeks[i] = new JLabel(weekName[i]);
			weeks[i].setFont(f);
			weekpanel.add(weeks[i]);
		}

		// ��������
		daypanel = new JPanel();
		cp.add(daypanel);
		daypanel.setBounds(20, 150, 560, 240);
		daypanel.setOpaque(false);
		daypanel.setLayout(new GridLayout(6, 7));
		for (int i = 0; i < 42; i++) {
			days[i] = new JLabel("");
			days[i].setForeground(Color.RED);
			days[i].setFont(new Font("Jokerman", Font.BOLD, 25));
			daypanel.add(days[i]);
		}

		// ���������ĸ�ʽ
		Calendar cale = null;
		cale = Calendar.getInstance();
		cale.add(Calendar.MONTH, 0);
		cale.set(Calendar.DAY_OF_MONTH, 1);
		int dow = cale.get(Calendar.DAY_OF_WEEK);// ��ȡ���µ�һ�������ڼ�

		cale.add(Calendar.MONTH, 1);
		cale.set(Calendar.DAY_OF_MONTH, 0);
		int maxDate = cale.get(Calendar.DAY_OF_MONTH);// ��ȡ�����ж�����
		int ptr = 1;
		int ptr2 = dow - 1;

		// ͻ����ǰ����
		int today = currentDate.getDate();
		for (int i = 0; i < maxDate; i++) {
			days[ptr2].setText("   " + ptr);
			if (ptr == today) {
				days[ptr2].setForeground(Color.BLUE);
				days[ptr2].setFont(new Font("Jokerman", Font.BOLD, 35));
				days[ptr2].setText("  " + ptr);
			}
			ptr++;
			ptr2++;
		}

		// ��ʼ���л����ڹ�������Ϣ
		yearInput.setText(theYear.toString());
		monthList.setSelectedIndex(currentDate.getMonth());

		// ���Ӽ�����
		// �ı����
		yearInput.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String yearIn;
				yearIn = yearInput.getText();
				Integer y = Integer.valueOf(yearIn);
				currentYear.setText(y.toString());
				monthList.setSelectedIndex(0);
			}

		});

		// �ı��·�
		monthList.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent ie) {

				Calendar cal = null;
				String year;
				year = currentYear.getText();
				if (ie.getStateChange() == ItemEvent.SELECTED) {
					String date;
					SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
					int y = Integer.valueOf(year).intValue();
					int m = monthList.getSelectedIndex() + 1;
					cal = Calendar.getInstance();
					date = "" + y + "-" + m + "-" + 1;
					try {
						cal.setTime(format.parse(date));
					} catch (ParseException e1) {
						// TODO �Զ����ɵ� catch ��
						e1.printStackTrace();
					}
					int dow = cal.get(Calendar.DAY_OF_WEEK);// ��ȡ���µ�һ�������ڼ�
					cal.roll(Calendar.DATE, -1);
					int maxDate = cal.get(Calendar.DAY_OF_MONTH);// ��ȡ�����ж�����
					int ptr = 1;
					int ptr2 = dow - 1;

					// ��������
					for (int i = 0; i < 42; i++) {
						days[i].setText("");
						days[i].setForeground(Color.RED);
						days[i].setFont(new Font("Jokerman", Font.BOLD, 25));
					}
					// ͻ����ǰ����
					int today = currentDate.getDate();
					for (int i = 0; i < maxDate; i++) {
						days[ptr2].setText("   " + ptr);
						if (ptr == today) {
							if (y == currentDate.getYear() + 1900 && m == currentDate.getMonth() + 1) {
								days[ptr2].setForeground(Color.BLUE);
								days[ptr2].setFont(new Font("Jokerman", Font.BOLD, 35));
								days[ptr2].setText("  " + ptr);
							}
						}
						ptr++;
						ptr2++;
					}

					switch (m) {
					case 1:
						currentMonth.setText("January");
						break;
					case 2:
						currentMonth.setText("Feburary");
						break;
					case 3:
						currentMonth.setText("March");
						break;
					case 4:
						currentMonth.setText("April");
						break;
					case 5:
						currentMonth.setText("May");
						break;
					case 6:
						currentMonth.setText("June");
						break;
					case 7:
						currentMonth.setText("July");
						break;
					case 8:
						currentMonth.setText("August");
						break;
					case 9:
						currentMonth.setText("September");
						break;
					case 10:
						currentMonth.setText("October");
						break;
					case 11:
						currentMonth.setText("November");
						break;
					case 12:
						currentMonth.setText("December");
						break;
					}
				}

			}
		});

		mc = new MyClient();
		if (mc.client == null) {

		}
		if (mc.client != null) {
			try {
				String eventtoserver = new String();
				BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("events.txt")));
				while ((eventtoserver = in.readLine()) != null) {
					System.out.println(eventtoserver);
					mc.sendMessage(eventtoserver + "\n");
				}
				in.close();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

		// ��ʾ�¼�����
		eventBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Thread(new EventWnd()).start();
			}
		});

	}

	// ����ȫ���¼�, �����ж��Ƿ񵯳��¼����Ѵ���
	public void traversefile() {
		try {
			String tempstr = new String();
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("events.txt")));
			while ((tempstr = in.readLine()) != null) {
				// System.out.println(tempstr.substring(0, 17));
				metime.add(tempstr.substring(0, 17));
				mecontent.add(tempstr.substring(17));
			}
			in.close();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	// �����¼�����
	public void reminder() {
		traversefile();
		Calendar curr = Calendar.getInstance();
		String currenttime = new String();
		int year = curr.get(Calendar.YEAR);
		int month = curr.get(Calendar.MONTH) + 1;
		int day = curr.get(Calendar.DAY_OF_MONTH);
		int hour = curr.get(Calendar.HOUR_OF_DAY);
		int minute = curr.get(Calendar.MINUTE);
		int second = curr.get(Calendar.SECOND);
		currenttime = String.valueOf(year) + "-" + String.format("%02d", month) + "-" + String.format("%02d", day);
		currenttime += " " + String.format("%02d", hour) + ":" + String.format("%02d", minute) + " ";

		// System.out.println("currenttime: " + currenttime);
		if (metime.contains(currenttime) && second == 0) {
			Component jPanel = new JPanel();
			JOptionPane.showMessageDialog(jPanel, mecontent.get(metime.indexOf(currenttime)), "����",
					JOptionPane.WARNING_MESSAGE);
		}
	}

	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
		CalendarWnd cal = new CalendarWnd();
		RemindThread t = new RemindThread(cal);
		try {
			t.sleep(100);
			t.run();
		} catch (InterruptedException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
}

// ���߳����ڵ����¼����Ѵ���
class RemindThread extends Thread {

	CalendarWnd cw;

	public RemindThread(CalendarWnd c) {
		cw = c;
	}

	@Override
	public void run() {
		while (true) {
			cw.reminder();
		}
	}
}
