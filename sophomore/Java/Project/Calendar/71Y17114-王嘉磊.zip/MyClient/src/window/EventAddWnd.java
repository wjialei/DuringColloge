package window;

import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import java.io.*;
import java.util.ArrayList;

public class EventAddWnd extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private ImageIcon awbackground;

	private JLabel timeLabel, recordLabel, yearLabel, monthLabel, dateLabel, hourLabel, minLabel;
	private JTextField yearJtf, monthJtf, dateJtf, hourJtf, minJtf;
	private JTextArea recordArea;
	private JButton btn101, btn102;
	/*
	 * labelFont101: ����������ʾ��ǩ������ labelFont102: �������� �£��գ��� ��ǩ������ btnFont101:
	 * �������ð�ť�е�����
	 */
	private Font labelFont101, labelFont102, btnFont101;

	public EventAddWnd() {

		this.setTitle("Event Adding");
		this.setSize(400, 400);
		this.setVisible(true);
		this.setLayout(null);
		this.setLocationRelativeTo(null);
		this.setResizable(false);

		// ���ӱ���
		awbackground = new ImageIcon("background3.jpg");
		JLabel awbackGroundLabel = new JLabel(awbackground);
		awbackGroundLabel.setBounds(0, 0, 400, 400);
		JPanel imagePanel = (JPanel) this.getContentPane();
		imagePanel.setOpaque(false);
		this.getLayeredPane().add(awbackGroundLabel, new Integer(Integer.MIN_VALUE));

		Container awcp = this.getContentPane();

		labelFont101 = new Font("΢���ź�", Font.BOLD, 15);
		labelFont102 = new Font("΢���ź�", Font.BOLD, 12);
		btnFont101 = new Font("΢���ź�", Font.BOLD, 10);

		// �������ڲ���
		timeLabel = new JLabel("Please Set a Time for Your Event");
		timeLabel.setFont(labelFont101);
		timeLabel.setBounds(70, 5, 250, 45);
		// ��
		yearLabel = new JLabel("Year:");
		yearLabel.setFont(labelFont102);
		yearLabel.setBounds(50, 55, 50, 20);
		yearJtf = new JTextField();
		yearJtf.setBounds(100, 55, 100, 20);
		// ��
		monthLabel = new JLabel("Month:");
		monthLabel.setFont(labelFont102);
		monthLabel.setBounds(50, 80, 50, 20);
		monthJtf = new JTextField();
		monthJtf.setBounds(100, 80, 100, 20);
		// ��
		dateLabel = new JLabel("Date:");
		dateLabel.setFont(labelFont102);
		dateLabel.setBounds(50, 105, 50, 20);
		dateJtf = new JTextField();
		dateJtf.setBounds(100, 105, 100, 20);
		// ʱ
		hourLabel = new JLabel("Hour:");
		hourLabel.setFont(labelFont102);
		hourLabel.setBounds(210, 70, 50, 20);
		hourJtf = new JTextField();
		hourJtf.setBounds(260, 70, 100, 20);
		// ��
		minLabel = new JLabel("Min:");
		minLabel.setFont(labelFont102);
		minLabel.setBounds(210, 95, 50, 20);
		minJtf = new JTextField();
		minJtf.setBounds(260, 95, 100, 20);

		// ��¼�¼����ݲ���
		recordLabel = new JLabel("Please Input Your Event");
		recordLabel.setFont(labelFont101);
		recordLabel.setBounds(70, 150, 250, 45);
		recordArea = new JTextArea();
		recordArea.setBounds(80, 200, 200, 100);

		// ��ť
		btn101 = new JButton("Verify");
		btn101.setFont(btnFont101);
		btn101.setBounds(80, 310, 75, 30);
		btn102 = new JButton("Cancel");
		btn102.setFont(btnFont101);
		btn102.setBounds(205, 310, 75, 30);

		// ����������������
		awcp.add(timeLabel);
		awcp.add(recordLabel);
		awcp.add(recordArea);
		awcp.add(yearLabel);
		awcp.add(yearJtf);
		awcp.add(monthLabel);
		awcp.add(monthJtf);
		awcp.add(dateLabel);
		awcp.add(dateJtf);
		awcp.add(hourLabel);
		awcp.add(hourJtf);
		awcp.add(minLabel);
		awcp.add(minJtf);
		awcp.add(btn101);
		awcp.add(btn102);

		// ���ü�����
		btn101.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String dayStr = new String(yearJtf.getText() + "-" + monthJtf.getText() + "-" + dateJtf.getText() + " "
						+ hourJtf.getText() + ":" + minJtf.getText() + " ");
				String eventStr = new String("Event: " + recordArea.getText() + "\r\n");
				File file = new File("events.txt");
				try {
					FileWriter w = new FileWriter(file, true);
					w.write(dayStr + eventStr);
					w.close();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.out.println(dayStr + eventStr);
				dispose();
			}
		});

		btn102.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
	}
}
