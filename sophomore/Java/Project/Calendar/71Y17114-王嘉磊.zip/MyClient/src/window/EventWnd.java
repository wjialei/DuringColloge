package window;

import java.awt.*;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;

import java.io.*;

import javax.swing.*;

import java.text.SimpleDateFormat;

import java.util.Date;

public class EventWnd extends JFrame implements Runnable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private ImageIcon ewbackground;

	/*
	 * btn001 : ���������¼� btn002: ������ʾ�¼� btn003: ���ڹرմ���
	 */
	private JButton btn001, btn002, btn003;

	/*
	 * jl001,jl002: ������ʾ��ǰʱ�� ji003: ������ʾ��ǩ
	 */
	private JLabel jl001, jl002, jl003;

	// ��ʾ�����ӵ�ʱ��
	private JTextArea jta001;

	// �����ؼ�
	private JScrollPane scroll001;

	// �Զ�������
	private Font labelFont001, btnFont001;

	public EventWnd() {

		this.setTitle("Event");
		this.setSize(450, 400);
		this.setVisible(true);
		this.setLayout(null);
		this.setLocationRelativeTo(null);
		this.setResizable(false);

		// ���ӱ���
		ewbackground = new ImageIcon("background2.jpg");
		JLabel ewbackGroundLabel = new JLabel(ewbackground);
		ewbackGroundLabel.setBounds(0, 0, 450, 400);
		JPanel imagePanel = (JPanel) this.getContentPane();
		imagePanel.setOpaque(false);
		this.getLayeredPane().add(ewbackGroundLabel, new Integer(Integer.MIN_VALUE));

		Container ewcp = this.getContentPane();

		labelFont001 = new Font("΢���ź�", Font.BOLD, 15);
		btnFont001 = new Font("΢���ź�", Font.BOLD, 10);

		// ʱ���ǩ
		// ����
		jl001 = new JLabel();
		jl001.setFont(labelFont001);
		jl001.setBounds(125, 5, 200, 20);
		// ʱ��
		jl002 = new JLabel();
		jl002.setFont(labelFont001);
		jl002.setBounds(190, 30, 200, 20);

		// ��ť
		btn001 = new JButton("Add");
		btn001.setFont(btnFont001);
		btn001.setBounds(70, 75, 75, 30);
		btn002 = new JButton("Show");
		btn002.setFont(btnFont001);
		btn002.setBounds(185, 75, 75, 30);
		btn003 = new JButton("Cancel");
		btn003.setFont(btnFont001);
		btn003.setBounds(300, 75, 75, 30);

		// ��ʾ�¼�
		jl003 = new JLabel("Your Events");
		jl003.setFont(labelFont001);
		jl003.setBounds(175, 110, 100, 20);
		jta001 = new JTextArea();
		jta001.setBounds(45, 140, 350, 200);

		// ���ӹ�����, ������
		/*
		 * scroll001 = new JScrollPane(jta001); scroll001.setBounds(395, 140, 15, 200);
		 * scroll001.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER
		 * );
		 * scroll001.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		 * scroll001.setWheelScrollingEnabled(true); scroll001.setPreferredSize(new
		 * Dimension(15, 200));
		 */
		ewcp.add(jl001);
		ewcp.add(jl002);
		ewcp.add(btn001);
		ewcp.add(btn002);
		ewcp.add(btn003);
		ewcp.add(jl003);
		ewcp.add(jta001);

		btn002.addActionListener(new ActionListener() {

			File file = new File("events.txt");
			String text;

			@Override
			public void actionPerformed(ActionEvent ae) {
				try {
					String line = new String();
					BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
					text = new String();
					while ((line = in.readLine()) != null) {
						System.out.println(line);
						text += line + "\n";
						// jta001.append(line + "\n");

					}
					in.close();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				jta001.setText(text);
			}
		});

		btn003.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				dispose();
			}
		});

		btn001.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				new EventAddWnd();
			}
		});
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while (true) {
			try {
				jl001.setText(new SimpleDateFormat("yyyy - MM - dd   EEEE").format(new Date()));
				jl002.setText(new SimpleDateFormat("HH:mm:ss").format(new Date()));
			} catch (Throwable t) {
				t.printStackTrace();
			}
		}
	}
}
