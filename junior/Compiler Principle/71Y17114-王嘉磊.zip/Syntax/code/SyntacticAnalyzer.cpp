#include <iostream>
#include "stdio.h"
using namespace std;

/*
Solve the simple arithmetic expression by recursive descent parsing.
The following are expressions which have eliminated left recursion:
    S -> TS1
    S1 -> +TS1 S1 -> -TS1 S1 -> ��
    T -> FT1
    T1 -> *FT1 T1 -> /FT1 T1 -> ��
    F -> i
    i represents letter or number
*/
// Read character one by one
char ch = ' ';
// Get the code
char token[50];
// Control the recursive procedure
int flag = 0;
// Record the current position
int pos = 0;

void S();
void S1();
void T();
void T1();
void F();

// Determine whether a char is a letter
bool isLetter(char c)
{
    if((c >= 'a' && c <='z') || (c >= 'A' && c <= 'Z'))
        return true;
    else
        return false;
}

// Determine whether a char is a digit
bool isDigit(char c)
{
    if(c >= '0' && c <= '9')
        return true;
    else
        return false;
}

// Print the string which has been analyzed
void output(int i)
{
    for(int n = 0; n <= i; n++)
    {
        cout<<token[n];
    }
    cout<<"\t";
}

// Print the string which has not been analyzed
void outputRest(int j)
{
    cout<<"\t";
    j++;
    while(token[j] != '\0')
    {
        cout<<token[j];
        j++;
    }
    cout<<endl;
}

// S function
void S()
{
    if(flag==0)
    {
        output(pos);
        cout<<"S -> TS1";
        outputRest(pos);
        T();
        S1();
    }
}

// S1 function
void S1()
{
    if(flag==0)
    {
        if(token[pos]=='+')
        {
            output(pos);
            cout<<"S1 -> +TS1";
            outputRest(pos);
            pos++;
            T();
            S1();
        }
        else if(token[pos]=='-')
        {
            output(pos);
            cout<<"S1 -> -TS1";
            outputRest(pos);
            pos++;
            T();
            S1();
        }
        else
        {
            output(pos);
            cout<<"S1 -> ��";
            outputRest(pos);
        }
    }
}

// T function
void T()
{
    if(flag==0)
    {
        output(pos);
        cout<<"T -> FT1";
        outputRest(pos);
        F();
        T1();
    }
}

// T1 function
void T1()
{
    if(flag==0)
    {
        if(token[pos]=='*')
        {
            output(pos);
            cout<<"T1 -> *FT1";
            outputRest(pos);
            pos++;
            F();
            T1();
        }
        else if(token[pos]=='/')
        {
            output(pos);
            cout<<"T1 -> *FT1";
            outputRest(pos);
            pos++;
            F();
            T1();
        }
        else
        {
            output(pos);
            cout<<"T1 -> ��";
            outputRest(pos);
        }
    }
}

// F function
void F()
{
    if(flag==0)
    {
        if(isDigit(token[pos]) || isLetter(token[pos]))
        {

            if((token[pos+1]=='+') || (token[pos+1]=='-') || (token[pos+1]=='*') || (token[pos+1]=='/'))
            {
                output(pos);
                cout<<"F -> i\t";
                outputRest(pos);
                pos++;
            }
        }
        else
        {
            cout<<"ERROR!"<<endl;
            flag = 1;
        }
    }
}

// Syntax Analyzer
void analyze(FILE* f)
{
    int i = 0;
    while((ch = fgetc(f)) != EOF)
    {
        // Eliminate ' ' character
        if(ch != ' ')
        {
            token[i] = ch;
            i++;
        }
    }
    cout<<"The code to analyze: "<<token<<endl;
    cout<<"current\t"<<"reduction\t"<<"rest"<<endl;
    S();
    if(flag == 0) cout<<"success!"<<endl;

}

int main()
{
    char input[30];
    FILE *f;
    cout<<"Please input the document's path and name to analyze: ";
    for(;;)
    {
        cin>>input;
        if((f = fopen(input, "r")) != NULL)
            break;
        else
            cout<<"ERROR PATH!"<<endl;
    }
    cout<<"The folllowing is the result of syntactic analysis:"<<endl;
    analyze(f);
    fclose(f);
    return 0;
}
