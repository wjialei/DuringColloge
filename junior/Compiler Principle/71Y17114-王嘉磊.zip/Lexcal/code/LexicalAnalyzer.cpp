#include <iostream>
#include "string.h"
#include "stdio.h"
using namespace std;

// The number of keywords
#define NUM 25

// key words
char* keyWords[NUM] = {"include", "using", "namespace", "std", "main", "void", "int", "double", "float",
                    "char", "string", "if", "else", "switch", "case", "default", "do", "while", "for", "continue",
                    "break", "return", "cin", "cout", "endl"};

// Get a token
char token[200];

// Get char
char ch;

// Determine whether a token is a keyword
bool isKey(char* token)
{
    for(int i = 0; i < NUM; i++)
    {
        if((strcmp(token,keyWords[i]) == 0))
            return true;
    }
    return false;
}

// Determine whether a char is a letter, which includes _
bool isLetter_(char c)
{
    if((c >= 'a' && c <='z') || (c >= 'A' && c <= 'Z') || (c == '_'))
        return true;
    else
        return false;
}

// Determine whether a char is a digit
bool isDigit(char c)
{
    if(c >= '0' && c <= '9')
        return true;
    else
        return false;
}

// Refresh token[]
void refresh()
{
    for(int i = 0; i < 200; i++)
    {
        token[i] = '\0';
    }
}

// Do lexical analysis
void analyze(FILE *f)
{
    int state = 0;
    while((ch = fgetc(f)) != EOF)
    {
        switch (state)
        {
            // initial state
            case 0:
            {
                if(ch == ' ' || ch == '\t' || ch == '\n'){}
                if(isLetter_(ch))
                {
                    token[0] = ch;
                    state = 1;
                }
                else if(isDigit(ch) || ch == '.')
                {
                    token[0] = ch;
                    state = 2;
                }
                else if(ch == '"')
                {
                    token[0] = '"';
                    state = 3;
                }
                else
                {
                    switch(ch)
                    {
                    case '\'':
                        token[0] = ch;
                        state = 13;
                        break;
                    case '<':
                        token[0] = ch;
                        state = 4;
                        break;
                    case '>':
                        token[0] = ch;
                        state = 5;
                        break;
                    case '=':
                        token[0] = ch;
                        state = 6;
                        break;
                    case '!':
                        token[0] = ch;
                        state = 7;
                        break;
                    case '+':
                        token[0] = ch;
                        state = 8;
                        break;
                    case '-':
                        token[0] = ch;
                        state = 9;
                        break;
                    case '*':
                        token[0] = ch;
                        cout<<token<<"\t"<<"operator"<<endl;
                        refresh();
                        break;
                    case '/':
                        token[0] = ch;
                        state = 12;
                        break;
                    case '%':
                        token[0] = ch;
                        cout<<token<<"\t"<<"operator"<<endl;
                        refresh();
                        break;
                    case '&':
                        token[0] = ch;
                        state = 10;
                        break;
                    case '|':
                        token[0] = ch;
                        state = 11;
                        break;
                    case '(':
                        token[0] = ch;
                        cout<<token<<"\t"<<"separator"<<endl;
                        refresh();
                        break;
                    case ')':
                        token[0] = ch;
                        cout<<token<<"\t"<<"separator"<<endl;
                        refresh();
                        break;
                    case '[':
                        token[0] = ch;
                        cout<<token<<"\t"<<"separator"<<endl;
                        refresh();
                        break;
                    case ']':
                        token[0] = ch;
                        cout<<token<<"\t"<<"separator"<<endl;
                        refresh();
                        break;
                    case '{':
                        token[0] = ch;
                        cout<<token<<"\t"<<"separator"<<endl;
                        refresh();
                        break;
                    case '}':
                        token[0] = ch;
                        cout<<token<<"\t"<<"separator"<<endl;
                        refresh();
                        break;
                    case ';':
                        token[0] = ch;
                        cout<<token<<"\t"<<"separator"<<endl;
                        refresh();
                        break;
                    case ':':
                        token[0] = ch;
                        cout<<token<<"\t"<<"separator"<<endl;
                        refresh();
                        break;
                    case ',':
                        token[0] = ch;
                        cout<<token<<"\t"<<"separator"<<endl;
                        refresh();
                        break;
                    case '#':
                        token[0] = ch;
                        cout<<token<<"\t"<<"separator"<<endl;
                        refresh();
                        break;
                    case '?':
                        token[0] = ch;
                        cout<<token<<"\t"<<"error character"<<endl;
                        refresh();
                        break;
                    case '~':
                        token[0] = ch;
                        cout<<token<<"\t"<<"error character"<<endl;
                        refresh();
                        break;
                    case '`':
                        token[0] = ch;
                        cout<<token<<"\t"<<"error character"<<endl;
                        refresh();
                        break;
                    case '@':
                        token[0] = ch;
                        cout<<token<<"\t"<<"error character"<<endl;
                        refresh();
                        break;
                    case '$':
                        token[0] = ch;
                        cout<<token<<"\t"<<"error character"<<endl;
                        refresh();
                        break;
                    case '^':
                        token[0] = ch;
                        cout<<token<<"\t"<<"error character"<<endl;
                        refresh();
                        break;
                    default:
                        break;
                    }
                }
                break;
            }
            // Analyze id and keyword
            case 1:
            {
                int i = 1;
                while (isDigit(ch)||isLetter_(ch))
                {
                    token[i] = ch;
                    ch = fgetc(f);
                    i++;
                }
                // retract a position for pointer
                fseek(f, -1L, SEEK_CUR);
                if(isKey(token))
                {
                    cout<<token<<"\t"<<"keyword"<<endl;
                    refresh();
                    state = 0;
                }
                else
                {
                    cout<<token<<"\t"<<"id"<<endl;
                    refresh();
                    state = 0;
                }
                break;
            }
            // Analyze digit
            case 2:
            {
                int i = 1;
                if(isDigit(token[0]))
                {
                    while(isDigit(ch))
                    {
                        token[i] = ch;
                        ch = fgetc(f);
                        i++;
                    }
                    if (ch == '.')
                    {
                        token[i] = ch;
                        ch = fgetc(f);
                        i++;
                    while(isDigit(ch))
                    {
                        token[i] = ch;
                        ch = fgetc(f);
                        i++;
                    }
                        fseek(f,-1L,SEEK_CUR);
                        cout<<token<<"\t"<<"float"<<endl;
                        refresh();
                        state = 0;
                    }
                    else
                    {
                        fseek(f,-1L,SEEK_CUR);
                        cout<<token<<"\t"<<"int"<<endl;
                        refresh();
                        state = 0;
                    }
                }
                else if(token[0] == '.')
                {
                    if(!isDigit(ch))
                    {
                        fseek(f,-1L,SEEK_CUR);
                        cout<<token<<"\t"<<"separator"<<endl;
                        refresh();
                        state = 0;
                    }
                    else
                    {
                        while(isDigit(ch))
                        {
                            token[i] = ch;
                            ch = fgetc(f);
                            i++;
                        }
                        fseek(f,-1L,SEEK_CUR);
                        cout<<token<<"\t"<<"float"<<endl;
                        refresh();
                        state = 0;
                    }
                }
                break;
            }
            // Analyze "
            case 3:
            {
                cout<<token[0]<<"\t"<<"separator"<<endl;
                refresh();
                int i = 0;
                while(ch != '"')
                {
                    token[i] = ch;
                    ch = fgetc(f);
                    i++;
                }
                cout<<token<<"\t"<<"string"<<endl;
                refresh();
                cout<<ch<<"\t"<<"separator"<<endl;
                state = 0;
                break;
            }
            // Analyze <
            case 4:
            {
                int i = 1;
                if(ch == '=' || ch == '<')
                {
                    token[i] = ch;
                    cout<<token<<"\t"<<"operator"<<endl;
                    refresh();
                    state = 0;
                }
                else
                {
                    fseek(f,-1L,SEEK_CUR);
                    cout<<token<<"\t"<<"operator"<<endl;
                    refresh();
                    state = 0;
                }
                break;
            }
            // Analyze >
            case 5:
            {
                int i = 1;
                if(ch == '=' || ch == '>')
                {
                    token[i] = ch;
                    cout<<token<<"\t"<<"operator"<<endl;
                    refresh();
                    state = 0;
                }
                else
                {
                    fseek(f,-1L,SEEK_CUR);
                    cout<<token<<"\t"<<"operator"<<endl;
                    refresh();
                    state = 0;
                }
                break;
            }
            // Analyze =
            case 6:
               {
                int i = 1;
                if(ch == '=')
                {
                    token[i] = ch;
                    cout<<token<<"\t"<<"operator"<<endl;
                    refresh();
                    state = 0;
                }
                else
                {
                    fseek(f,-1L,SEEK_CUR);
                    cout<<token<<"\t"<<"operator"<<endl;
                    refresh();
                    state = 0;
                }
                break;
            }
            // Anlyze !
            case 7:
            {
                int i = 1;
                if(ch == '=')
                {
                    token[i] = ch;
                    cout<<token<<"\t"<<"operator"<<endl;
                    refresh();
                    state = 0;
                }
                else
                {
                    fseek(f,-1L,SEEK_CUR);
                    cout<<token<<"\t"<<"operator"<<endl;
                    refresh();
                    state = 0;
                }
                break;
            }
            // Analyze +
            case 8:
            {
                int i = 1;
                if(ch == '+')
                {
                    token[i] = ch;
                    cout<<token<<"\t"<<"operator"<<endl;
                    refresh();
                    state = 0;
                }
                else
                {
                    fseek(f,-1L,SEEK_CUR);
                    cout<<token<<"\t"<<"operator"<<endl;
                    refresh();
                    state = 0;
                }
                break;
            }
            // Analyze -
            case 9:
            {
                int i = 1;
                if(ch == '-')
                {
                    token[i] = ch;
                    cout<<token<<"\t"<<"operator"<<endl;
                    refresh();
                    state = 0;
                }
                else
                {
                    fseek(f,-1L,SEEK_CUR);
                    cout<<token<<"\t"<<"operator"<<endl;
                    refresh();
                    state = 0;
                }
                break;
            }
            // Analyze &
            case 10:
            {
                int i = 1;
                if(ch == '&')
                {
                    token[i] = ch;
                    cout<<token<<"\t"<<"operator"<<endl;
                    refresh();
                    state = 0;
                }
                else
                {
                    fseek(f,-1L,SEEK_CUR);
                    cout<<token<<"\t"<<"operator"<<endl;
                    refresh();
                    state = 0;
                }
                break;
            }
            // Analyze |
            case 11:
            {
                int i = 1;
                if(ch == '|')
                {
                    token[i] = ch;
                    cout<<token<<"\t"<<"operator"<<endl;
                    refresh();
                    state = 0;
                }
                else
                {
                    fseek(f,-1L,SEEK_CUR);
                    cout<<token<<"\t"<<"operator"<<endl;
                    refresh();
                    state = 0;
                }
                break;
            }
            // Analyze /
            case 12:
            {
                int i = 1;
                if(ch == '/')
                {
                    token[i] = '/';
                    ch = fgetc(f);
                    i++;
                    while(ch != '\n')
                    {
                        token[i] = ch;
                        ch = fgetc(f);
                        i++;
                    }
                    cout<<token<<"\t"<<"annotation"<<endl;
                    refresh();
                    state = 0;
                }
                break;
            }
            // Analyze '
            case 13:
            {
                // Print the left '
                cout<<token[0]<<"\t"<<"separator"<<endl;
                refresh();
                // Print char
                // Print \0, \t, \', \n
                if(ch == '\'')
                {
                    token[0] = ch;
                    ch = fgetc(f);
                    token[1] = ch;
                    ch = fgetc(f);
                    cout<<token<<"\t"<<"char"<<endl;
                    refresh();
                    //Print the right '
                    if(ch == '\'')
                    {
                        cout<<ch<<"\t"<<"separator"<<endl;
                    }
                    else
                    {
                        cout<<ch<<"\t"<<"ERROR"<<endl;
                    }

                }
                else
                {
                    token[0] = ch;
                    ch = fgetc(f);
                    cout<<token[0]<<"\t"<<"char"<<endl;
                    refresh();
                    if(ch == '\'')
                    {
                        cout<<ch<<"\t"<<"separator"<<endl;
                    }
                    else
                    {
                        cout<<ch<<"\t"<<"ERROR"<<endl;
                    }
                }
                state = 0;
                break;
            }
            default:
                cout<<"There is no character"<<endl;
                break;
        }
    }
}
int main()
{
    char input[30];
    FILE *fpin;
    cout<<"Please input the document's name to analyze��";
    for(;;){
        cin>>input;
        if((fpin = fopen(input,"r")) != NULL)
            break;
        else
            cout<<"ERROE PATH!"<<endl;
    }
    cout<<"The following is the result:"<<endl;
    analyze(fpin);
    fclose(fpin);
    return 0;
}
